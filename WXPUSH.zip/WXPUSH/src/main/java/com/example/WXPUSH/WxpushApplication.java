package com.example.WXPUSH;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WxpushApplication {

	public static void main(String[] args) {
		SpringApplication.run(WxpushApplication.class, args);
	}

}
